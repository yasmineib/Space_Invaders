package invaders;

import invaders.Observer.Observer;
import invaders.Observer.Subject;

import java.util.ArrayList;
import java.util.List;

public class Time implements Subject {
    private long startTime = System.currentTimeMillis();
    private long elapsedTime;
    private List<Observer> observers = new ArrayList<>();


    public String getTimeElapsed() {
        elapsedTime = System.currentTimeMillis() - startTime;
        long seconds = (elapsedTime / 1000) % 60;
        long minutes = (elapsedTime / (1000 * 60)) % 60;
        String time = String.format("TIME: %02d:%02d", minutes, seconds);
        return time;
    }
    public long getElapsedtime(){getTimeElapsed(); return elapsedTime; }

    public void restoreTimeFromMemento(long savedTime){
        elapsedTime = savedTime;
        startTime = System.currentTimeMillis() - elapsedTime; // Adjust start time
        notifyObservers();
    }

    @Override
    public void attatchObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void detatchObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for(Observer o: observers){
            o.update();
        }

    }
}
