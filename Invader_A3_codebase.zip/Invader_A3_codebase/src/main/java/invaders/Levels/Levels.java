package invaders.Levels;

public interface Levels {
    public static Levels getInstance(){return null; };
    public String getConfigPath();

}