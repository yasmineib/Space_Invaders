package invaders.Observer;

public interface Observer {
    public void update();
}