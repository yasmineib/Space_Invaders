How to run: gradle run

Feauturs: 
- Difficulty
- Time and Score
- Undo
- Cheat

Classes per design pattern: 

Singleton:
- Levels
- HardLevel
- MediumLevel
- EasyLevel

Observer: 
- Subject
- Observer
- Score
- Time
- GameEngine
- GameWindow

Prototype: 
- Prototype
- Enemy
- Player
- PlayerProjectile
- EnemyProjectile

Memento: 
- Memento
- Caretaker
- GameEngine

KeyBoard functionalities: 
S - save
D - undo

P - remove all slow aliens
O - remove all fast aliens
L - remove all slow projectile
K - remove all fast projectiles

E - easy mode
M - medium mode
H - hard mode